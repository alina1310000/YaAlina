﻿using System;
using System.Collections.Generic;

namespace EpamTrainingDay4
{
    class Program
    {
        static void Main(string[] args)
        {
            var employees = new List<Employee>
            {
                new Employee(1, "Richter", 54),
                new Employee(2, "Griffin", 27),
                new Employee(3, "Grace", 29),
                new Employee(4, "Roy", 18),
                new Employee(5, "Turner", 28),
                new Employee(6, "Otis", 33),
                new Employee(7, "Gill", 26)
            };
            var projects = new List<Project>
            {
                new Project(1, "Project1", new DateTime(2019, 3, 25)),
                new Project(2, "Project2", new DateTime(2018, 6, 4)),
                new Project(3, "Project3", new DateTime(2017, 12, 25)),
                new Project(4, "Project4", new DateTime(2019, 1, 12))
            };

            var employeeProjects = new List<EmployeeProject>
            {
                new EmployeeProject(1, 1, 1),
                new EmployeeProject(2, 2, 1),
                new EmployeeProject(3, 3, 2),
                new EmployeeProject(4, 3, 3),
                new EmployeeProject(5, 4, 4),
                new EmployeeProject(6, 5, 3),
                new EmployeeProject(7, 5, 4),
                new EmployeeProject(8, 6, 1),
                new EmployeeProject(9, 7, 4)
            };

            var company = new Company(1, "EPAM", employees, projects, employeeProjects);
            var has2OrMoreProjects = company.Has2OrMoreProjects();
            Console.WriteLine("Employees who have 2 or more projects:");
            foreach (var item in has2OrMoreProjects)
            {
                Console.WriteLine(item.LastName);
            }
            var date = new DateTime(2019, 1, 1);
            var projectsSince = company.ProjectsSince(date);
            Console.WriteLine("\nProject since " + date.ToShortDateString() + ": ");
            foreach (var item in projectsSince)
            {
                Console.WriteLine(item.Name);
            }

            var employeeYounger30AndProjectLessThanYear = company.EmployeeYounger30AndProjectLessThanYear();
            Console.WriteLine("\nCount of projects where all employee younger 30 years and project started less than year ago: " + employeeYounger30AndProjectLessThanYear);
            var theOldestEmployeeWith1ProjectInThisYear = company.TheOldestEmployeeWith1ProjectInThisYear();
            Console.WriteLine("\nThe oldest employee with one project: " + theOldestEmployeeWith1ProjectInThisYear);
        }


    }
}
