﻿namespace EpamTrainingDay4
{
    class EmployeeProject
    {
        public int Id { get; set; }

        public int EmployeeId { get; set; }

        public int ProjectId { get; set; }

        public EmployeeProject(int id, int employeeId, int projectId)
        {
            Id = id;
            EmployeeId = employeeId;
            ProjectId = projectId;
        }
    }
}
