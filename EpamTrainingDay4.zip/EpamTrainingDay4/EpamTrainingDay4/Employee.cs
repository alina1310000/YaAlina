﻿namespace EpamTrainingDay4
{
    class Employee
    {
        public int Id { get; set; }

        public string LastName { get; set; }

        public int Age { get; set; }

        public Employee(int id, string lastName, int age)
        {
            Id = id;
            LastName = lastName;
            Age = age;
        }
    }
}
