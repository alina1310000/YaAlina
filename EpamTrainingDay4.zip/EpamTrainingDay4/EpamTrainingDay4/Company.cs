﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace EpamTrainingDay4
{
    class Company
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public List<Employee> Employees { get; set; }

        public List<Project> Projects { get; set; }

        public List<EmployeeProject> EmployeeProjects { get; set; }

        public Company(int id, string name, List<Employee> employees, List<Project> projects,
            List<EmployeeProject> employeeProjects)
        {
            Id = id;
            Name = name;
            Employees = employees;
            Projects = projects;
            EmployeeProjects = employeeProjects;
        }


        public List<Project> ProjectsSince(DateTime startDate) =>
            Projects.Where(x => x.StartDate >= startDate).ToList();

        public List<Employee> Has2OrMoreProjects() => Employees.GroupJoin(EmployeeProjects, employee => employee.Id,
            employeeProject => employeeProject.EmployeeId, (employee, employeeProjects) => new
            {
                Employee = employee,
                countProjects = employeeProjects.Count()
            }).Where(x => x.countProjects >= 2).Select(x => x.Employee).OrderBy(x => x.LastName).ToList();

        public int EmployeeYounger30AndProjectLessThanYear() => Projects
            .Where(project => project.StartDate >= DateTime.Today.AddYears(-1))
            .Join(EmployeeProjects, project => project.Id, employeeProject => employeeProject.ProjectId,
                (project, employeeProject) => new { projId = project.Id, project.StartDate, employeeProject.EmployeeId })
            .Join(Employees, x => x.EmployeeId, z => z.Id,
                (project, employee) => new { project.projId, project.StartDate, employee })
            .GroupBy(x => x.projId)
            .Count(x => x.All(z => z.employee.Age < 30));

        public string TheOldestEmployeeWith1ProjectInThisYear() => Employees
                .GroupJoin(EmployeeProjects, x => x.Id, z => z.EmployeeId,
                    (employee, employeeProject) => new { employee, countProject = employeeProject.Count() })
                .Where(x => x.countProject == 1).Select(x => x.employee).OrderByDescending(x => x.Age).First().LastName;
    }
}
